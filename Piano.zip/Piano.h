#ifndef PIANO_H
#define PIANO_H
#include<Arduino.h>
class Piano {
  private: 
  byte pin;
  public:
  Piano(byte pin);

  void init();//enable speaker
  
  void play_Middle_c();//play note middle C
  
  void play_Treble_d();//play note D
  
  void play_Treble_e();//play note E

  void play_Treble_f();//play note F

  void play_Treble_g();//play note G

  void play_Treble_a();//play note A

  void play_Treble_b();//play note B

  void play_Upper_C();//play Upper C

  void play_Treble_a_sharp();//play A sharp

  void play_Bass_c();

  void play_Bass_c_sharp();

  void play_Bass_d();

  void play_Bass_d_sharp();

  void play_Bass_e();

  void play_Bass_f();

  void play_Bass_f_sharp();

  void play_Bass_g();

  void play_Bass_g_sharp();

  void play_Bass_a();

  void play_Bass_a_sharp();

  void play_Bass_b();
  
  void noPlay();//stops music
};
#endif
