#ifndef PIANO_H
#define PIANO_H
#include<Arduino.h>
class Piano {
  private: 
  byte pin;
  public:
  Piano(byte pin);

  void init();//enable speaker
  
  void play_c();//play note middle C
  
  void play_d();//play note D
  
  void play_e();//play note E

  void play_f();//play note F

  void play_g();//play note G

  void play_a();//play note A

  void play_b();//play note B

  void play_C();//play Upper C
};
#endif
