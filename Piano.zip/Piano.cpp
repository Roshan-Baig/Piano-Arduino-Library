#include "Piano.h"

Piano::Piano(byte pin) {
  this->pin = pin;
  init();
}

void Piano::init()
{
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
}

void Piano::play_c() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1915);
  digitalWrite(pin, LOW);
  delayMicroseconds(1915);                                                                                                                                                
}

void Piano::play_d() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1700);
  digitalWrite(pin, LOW);
  delayMicroseconds(1700);
}

void Piano::play_e()
{
  digitalWrite(pin, HIGH);
  delayMicroseconds(1519);
  digitalWrite(pin, LOW);
  delayMicroseconds(1519);
}

void Piano::play_f() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1432);
  digitalWrite(pin, LOW);
  delayMicroseconds(1432);
}

void Piano::play_g() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1275);
  digitalWrite(pin, LOW);
  delayMicroseconds(1275);
}

void Piano::play_a() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1136);
  digitalWrite(pin, LOW);
  delayMicroseconds(1136);
}

void Piano::play_b() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1014);
  digitalWrite(pin, LOW);
  delayMicroseconds(1014); 
}

void Piano::play_C() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(956);
  digitalWrite(pin, LOW);
  delayMicroseconds(956);
}
void Piano::noPlay() {
  digitalWrite(pin, LOW);
}
