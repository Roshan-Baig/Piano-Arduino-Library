#include "Piano.h"

Piano::Piano(byte pin) {
  this->pin = pin;
  init();
}

void Piano::init()
{
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
}

void Piano::play_Middle_c() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1915);
  digitalWrite(pin, LOW);
  delayMicroseconds(1915);                                                                                                                                                
}

void Piano::play_Treble_d() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1700);
  digitalWrite(pin, LOW);
  delayMicroseconds(1700);
}

void Piano::play_Treble_e()
{
  digitalWrite(pin, HIGH);
  delayMicroseconds(1519);
  digitalWrite(pin, LOW);
  delayMicroseconds(1519);
}

void Piano::play_Treble_f() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1432);
  digitalWrite(pin, LOW);
  delayMicroseconds(1432);
}

void Piano::play_Treble_g() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1275);
  digitalWrite(pin, LOW);
  delayMicroseconds(1275);
}

void Piano::play_Treble_a() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1136);
  digitalWrite(pin, LOW);
  delayMicroseconds(1136);
}

void Piano::play_Treble_b() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(1014);
  digitalWrite(pin, LOW);
  delayMicroseconds(1014); 
}

void Piano::play_Upper_C() {
  digitalWrite(pin, HIGH);
  delayMicroseconds(956);
  digitalWrite(pin, LOW);
  delayMicroseconds(956);
}

void Piano::play_Treble_a_sharp() {
  tone(pin,466,100);
}

void Piano::play_Bass_c() {
  tone(pin,131,100);
}

void Piano::play_Bass_c_sharp() {
  tone(pin,139,100);
}

void Piano::play_Bass_d() {
  tone(pin,147,100);
}

void Piano::play_Bass_d_sharp() {
  tone(pin,156,100);
}

void Piano::play_Bass_e() {
  tone(pin,165,100);
}

void Piano::play_Bass_f() {
  tone(pin,175,100);
}

void Piano::play_Bass_f_sharp() {
  tone(pin,185,100);
}

void Piano::play_Bass_g() {
  tone(pin,196,100);
}

void Piano::play_Bass_g_sharp() {
  tone(pin,208,100);
}

void Piano::play_Bass_a() {
  tone(pin,220,100);
}

void Piano::play_Bass_a_sharp() {
  tone(pin,233,100);
}

void Piano::play_Bass_b() {
  tone(pin,247,100);
}

void Piano::noPlay() {
  digitalWrite(pin, LOW);
}
